Mysqldump is a django package that is used to generate the logical backup of the MySQL database

generate backup of the MySQL database:

./manage.py dumpdb


setting.py
-------------- 

DBDUMP_DIR

define directory to store dump data.