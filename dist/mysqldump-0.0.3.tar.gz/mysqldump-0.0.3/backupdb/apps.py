from django.apps import AppConfig


class BackupdbConfig(AppConfig):
    name = 'backupdb'
